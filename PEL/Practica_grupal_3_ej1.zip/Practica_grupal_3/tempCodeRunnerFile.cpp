
                if (it.IsGroup(input))
                    found_albums.push_back(it);
            