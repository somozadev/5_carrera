        while(!isEmpty())
