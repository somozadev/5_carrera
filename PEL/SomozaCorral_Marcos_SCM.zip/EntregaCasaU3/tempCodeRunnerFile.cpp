

    for (const auto &i : vec)
    {
        cout << i.getData() << " ";
    }
    cout << endl;
}

int main()
{
    vector<MyClass> vec;

    vec.push_back((MyClass(10)));
    vec.push_back((MyClass(11)));
    cout << "------------------" << endl;
    printVec(vec);
    cout << "------------------" << endl;

    return EXIT_SUCCESS;
}